#ifndef __UTIL_H
#define __UTIL_H

#include <string>

using namespace std;


void string_replace(string&s1,const string&s2,const string&s3);

#endif